package org.multichoice.resources;

public abstract class FileDefinitions {
	
	public static final String propertiesFilename = "./terrain.properties";
	public static final String inputFileName = "./input_large_map.txt";
	public static final String outputfile = "./large_map.txt";
	public static final String inputFile_verifytestinputMap = "./verify_testinput_map.txt";
	public static final String inputFile_testinputMap = "./testinput_map.txt";

}
