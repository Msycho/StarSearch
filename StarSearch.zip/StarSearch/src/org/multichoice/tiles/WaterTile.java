package org.multichoice.tiles;

import org.multichoice.interfaces.TileType;

/**
 * @author Sipho Moerane
 *
 */
public class WaterTile extends Tile {
	
	private static final String TILE_DESCRIPTION = "Water Tile";

	public WaterTile(int xCordinate,int yCordinate) {
		
		super.setTileDescription(TILE_DESCRIPTION);
		super.setxCordinate(xCordinate);
		super.setyCordinate(yCordinate);
		super.setImageIcon(TileType.NON_WARLKABLE_WATER);
	}
}
