package org.multichoice.tiles;

/**
 * @author Sipho Moerane
 *
 */

import org.multichoice.interfaces.TileType;

/**
 * @author Sipho Moerane
 *
 */

public class TileFactory {
	
	private static TileFactory tileFactoryInstance = null;

	public static TileFactory getInstance() {
		
		if (tileFactoryInstance == null) {
			tileFactoryInstance = new TileFactory();// One factory instance (Singleton)
		}
		return tileFactoryInstance;
	}

	public Tile getTile(char tileType, int x, int y) {
		
		Tile tile  = null;
		
		switch (tileType){
			case TileType.NON_WARLKABLE_WATER:
				tile = new WaterTile(x, y);
				tile.setWalkable(false);
				break;
				
			case TileType.WALKABLE_FLATLAND_START:	
				tile = new FlatLandTile(x, y);
				tile.setStartTile(true);
				break;
				
			case TileType.WALKABLE_FLATLAND: 
				tile = new FlatLandTile(x, y);
				break;
				
			case TileType.WALKABLE_FLATLAND_GOAL:
				tile = new FlatLandTile(x, y);
				tile.setGoalTile(true);
				break;
				
			case TileType.WALKABLE_FOREST: 	
				tile = new ForestTile(x,  y);
				break;
				
			case TileType.WALKABLE_MOUNTAIN: 
				tile = new MountainTile(x, y);
				break;
				
			default:
				System.out.println("Not a Valid Tile");
		}
		
		return tile;
	}
}
