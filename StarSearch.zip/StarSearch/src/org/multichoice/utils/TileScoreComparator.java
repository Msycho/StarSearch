package org.multichoice.utils;

import java.util.Comparator;

import org.multichoice.tiles.Tile;

public class TileScoreComparator implements Comparator<Tile>{
	
	@Override
	public int compare(Tile firstTile, Tile secondTile) {
		
		return (firstTile.getTileScore() - secondTile.getTileScore());
	}

}
