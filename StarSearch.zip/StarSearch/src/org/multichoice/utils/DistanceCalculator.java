package org.multichoice.utils;

/**
 * @author Sipho Moerane
 *
 */
public class DistanceCalculator {

public static final int ERROR_INVALID_CODE = Integer.MAX_VALUE; 

private static DistanceCalculator instance = null;
	
	private DistanceCalculator() {
	}
	
	public static DistanceCalculator getInstance() {
		if (instance == null) {
			instance = new DistanceCalculator();
		}
		
		return instance;
	}
	
	
	/**
	 * calculates the L1 distance between 2 points using Manhattan distance 
	 */
	public int calculateDistance(int x1, int y1, int x2, int y2) {
		int result = ERROR_INVALID_CODE;
		
		result = (Math.abs(x1 - x2) + Math.abs(y1 - y2));
		
		return result;
	}
}
