package org.multichoice.executor;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import org.multichoice.interfaces.TileType;
import org.multichoice.resources.FileDefinitions;
import org.multichoice.tiles.Tile;
import org.multichoice.utils.DistanceCalculator;
import org.multichoice.utils.TileScoreComparator;

public class StarSearchProcess {

	private Tile bestTileFound = null;
	private static MapLayout terrainLayout = null;
	private Tile[][] tileGrid = null;
	
	public StarSearchProcess() {
		terrainLayout = MapLayout.getInstance();
		if (terrainLayout!=null && terrainLayout.getTileGrid()!=null) {
			tileGrid = new Tile[terrainLayout.getRows()][terrainLayout.getColumns()];
			tileGrid = terrainLayout.getTileGrid();
		}
	}

	public static void main(String[] args) {
		System.out.println( "Star Search Staring !!!!");
		StarSearchProcess finder = new StarSearchProcess();
	
		if (finder.processMapLayout()) {
			
			//finder.printMapLayout();
			
			finder.createOuputFile();
			
		}
	
		System.out.println("Star Search Complete");
	}
	
	private void createOuputFile() {
	
		String outputFileName = FileDefinitions.outputfile;
		
		FileOutputStream fileOutStream = null;
		OutputStreamWriter osWriter = null;
		
		try {
		
			boolean done = false;
			File file = new File(outputFileName);
			
			fileOutStream = new FileOutputStream(file);
			osWriter = new OutputStreamWriter(fileOutStream);
			
			if (getTerrainLayout()!=null && getTerrainLayout().length>0) {
				
				for(int row=0; row<terrainLayout.getRows(); row++) {
					for(int col=0; col < terrainLayout.getColumns(); col++) {
						
						Tile printTile = getTerrainLayout()[row][col];
						osWriter.write(String.format("%s  ", printTile));
						done=true;
					}
					osWriter.write("\n");
				}	
			}
			
			if (done) {
				System.out.println(String.format("\n %s createOutputFile() FILE output created in %s , %s", this.getClass().getSimpleName(), 
										file.getAbsoluteFile().getName(), file.getAbsolutePath()));
			}
			
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
		    e.printStackTrace();
		    
		} finally {
			if (osWriter!=null) {
				try {
					osWriter.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
			
			if (fileOutStream!=null) {
				try {
					fileOutStream.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		}
	}

	public void printMapLayout() {

		
		if (getTerrainLayout()!=null && getTerrainLayout().length>0) {
			
			for(int row=0; row<terrainLayout.getRows(); row++) {
				System.out.println("\t");
				for(int col=0; col < terrainLayout.getColumns(); col++) {
					
					Tile printTile = getTerrainLayout()[row][col];
							
					if (col==0) {System.out.print("\t");}
					System.out.print(String.format("%s   ",  printTile));
				}
				System.out.println("\t");	
			}
			
		}
		
	}
	
	public boolean processMapLayout() {
		
		if (getTerrainLayout()!=null) {

			bestTileFound = terrainLayout.getStartTile();
			bestTileFound.setImageIcon(TileType.WALKABLE_BEST_PATH);

			for(int row=terrainLayout.getStartTile().getxCordinate(); 
					row<terrainLayout.getRows() ; row++) {
				
				for(int col=terrainLayout.getStartTile().getyCordinate(); 
								col<terrainLayout.getColumns(); col++) {

					List<Tile> choiceTiles = findWalkableChoices(bestTileFound);
					
					// find walkable choices for current Best path Tile
					if (choiceTiles!=null && !choiceTiles.isEmpty()) {
						bestTileFound = findBestTile(bestTileFound, choiceTiles);
						if (bestTileFound!=null) {
							bestTileFound.setImageIcon(TileType.WALKABLE_BEST_PATH);
							row = bestTileFound.getxCordinate();
							col = bestTileFound.getyCordinate();
							continue;
	
						}
					}
					
				}	
			}	
		}

		return true;
	}
	
	private Tile findBestTile(Tile bestTile, List<Tile> list) {

		int totalCost = 0;
		totalCost+=bestTile.getCost();
		
		if (bestTile.isStartTile()) {
			bestTile.setCost(0);
		}
		
		final Tile goalTile = terrainLayout.getGoalTile();
		
		for(Tile tileItem: list) {
			int distanceToGoal = DistanceCalculator.getInstance().calculateDistance(tileItem.getxCordinate(), tileItem.getyCordinate(), 
					goalTile.getxCordinate(), goalTile.getyCordinate());
				tileItem.setDistanceToGoal(distanceToGoal);

				// set choice tile score
			tileItem.setTileScore(Math.abs(totalCost + tileItem.getCost()) + Math.abs(tileItem.getDistanceToGoal()));
		}
		
		if (!list.isEmpty()) {
			Collections.sort(list, new TileScoreComparator());
			return list.get(0);
		}
		
		return null;
	}

	private List<Tile> findWalkableChoices(Tile bestTile) {

		List<Tile> choiceTiles = new ArrayList<Tile>();
		
		if (!bestTile.isWalkable()) {
			return choiceTiles;
		}

		
		bestTile.setImageIcon(TileType.WALKABLE_BEST_PATH);
		// current Tile indexes
		int neighX = bestTile.getxCordinate(), neighY = bestTile.getyCordinate();
		
		// not circling back
		addChoiceTile(choiceTiles, getNeighbourTile((neighX-1), neighY));
		addChoiceTile(choiceTiles, getNeighbourTile((neighX-1), (neighY-1)));
		addChoiceTile(choiceTiles, getNeighbourTile((neighX-1), (neighY+1)));
		
		
		addChoiceTile(choiceTiles, getNeighbourTile(neighX, (neighY-1)));
		addChoiceTile(choiceTiles, getNeighbourTile(neighX, (neighY+1)));
		
		addChoiceTile(choiceTiles, getNeighbourTile((neighX+1), neighY));
		addChoiceTile(choiceTiles, getNeighbourTile((neighX+1), (neighY-1)));
		addChoiceTile(choiceTiles, getNeighbourTile((neighX+1), (neighY+1)));
		
		return choiceTiles;
	}
	
	private void addChoiceTile(List<Tile> choiceTiles, Tile neighbourTile) {
		
		if (neighbourTile!=null && neighbourTile.isWalkable()  && (!neighbourTile.isChecked())) {
			
			if (neighbourTile.getImageIcon()!=TileType.WALKABLE_BEST_PATH) {
				choiceTiles.add(neighbourTile);
				neighbourTile.setChecked(true);
			}
		}
	}

	private Tile getNeighbourTile(int row, int col) {

		// check the boundries of the row & column
		if ((row>-1) && row<terrainLayout.getRows() && (col>-1 && col<terrainLayout.getColumns())) {
			
			Tile checkTile = getTerrainLayout()[row][col]; 
				return checkTile;
		}
		
		return null;
	}

	public Tile[][] getTerrainLayout() {
		return tileGrid;
	}
}

