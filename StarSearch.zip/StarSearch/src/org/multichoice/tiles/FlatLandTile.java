/**
 * 
 */
package org.multichoice.tiles;

import org.multichoice.interfaces.TileType;

/**
 * @author Sipho Moerane
 *
 */
public class FlatLandTile extends Tile{
	
	private static final String TILE_DESCRIPTION = "Flat Land Tile" ;
	
	private char imageIcon ;
	
	public FlatLandTile(int xCordinate,int yCordinate){
		
		super.setTileDescription(TILE_DESCRIPTION);
		super.setxCordinate(xCordinate);
		super.setyCordinate(yCordinate);
	}

	@Override
	public char getImageIcon() {
		
		if (isStartTile()) {
			imageIcon = TileType.WALKABLE_FLATLAND_START;
			
		} else if (isGoalTile()) {
			imageIcon = TileType.WALKABLE_FLATLAND_GOAL;
		} else {
			imageIcon = TileType.WALKABLE_FLATLAND;
		}
		return imageIcon;
	}
}
