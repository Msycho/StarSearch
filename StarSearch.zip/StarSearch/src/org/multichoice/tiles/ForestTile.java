package org.multichoice.tiles;

import org.multichoice.interfaces.TileType;

/**
 * @author Sipho Moerane
 *
 */

public class ForestTile extends Tile{
	
	private static final String TILE_DESCRIPTION = "Forest Tile";
	
	
	public ForestTile(int xCordinate,int yCordinate) {
		
		super.setTileDescription(TILE_DESCRIPTION);
		super.setxCordinate(xCordinate);
		super.setyCordinate(yCordinate);
		super.setImageIcon(TileType.WALKABLE_FOREST);
	}
}
