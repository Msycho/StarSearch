/**
 * 
 */
package org.multichoice.tiles;

/**
 * @author Sipho Moerane
 *
 */
public abstract class Tile {
	
	private int 	xCordinate 		= 0;
	private int 	yCordinate 		= 0;
	private String 	TileDescription = null;
	private int 	distanceToGoal 	= 0;
	private int 	tileScore 		= 0;
	private int 	cost 			= 0;
	private boolean isWalkable 		= false;
	private boolean isGoalTile 		= false;
	private boolean isStartTile 	= false;
	private char 	imageIcon;
	private boolean checked = false; 
	
	public int getxCordinate() {
		return xCordinate;
	}
	public void setxCordinate(int xCordinate) {
		this.xCordinate = xCordinate;	
	}
	public int getyCordinate() {
		return yCordinate;
	}
	public void setyCordinate(int yCordinate) {
		this.yCordinate = yCordinate;
	}
	public String getTileDescription() {
		return TileDescription;
	}
	public void setTileDescription(String tileDescription) {
		TileDescription = tileDescription;
	}
	public int getDistanceToGoal() {
		return distanceToGoal;
	}
	public void setDistanceToGoal(int distanceToGoal) {
		this.distanceToGoal = distanceToGoal;
	}
	public int getTileScore() {
		return tileScore;
	}
	public void setTileScore(int tileScore) {
		this.tileScore = tileScore;
	}
	public boolean isWalkable() {
		return isWalkable;
	}
	public void setWalkable(boolean isWalkable) {
		this.isWalkable = isWalkable;
	}
	public boolean isGoalTile() {
		return isGoalTile;
	}
	public void setGoalTile(boolean isGoalTile) {
		this.isGoalTile = isGoalTile;
	}
	public boolean isStartTile() {
		return isStartTile;
	}
	public void setStartTile(boolean isStartTile) {
		this.isStartTile = isStartTile;
	}
	public int getCost() {
		return cost;
	}
	public void setCost(int cost) {
		this.cost = cost;
	}
	public char getImageIcon() {
		return imageIcon;
	}
	public void setImageIcon(char imageIcon) {
		this.imageIcon = imageIcon;
	}
	public boolean isChecked() {
		return checked;
	}
	public void setChecked(boolean checked) {
		this.checked = checked;
	}

	@Override
	public String toString() {
		return String.valueOf(getImageIcon());

	}
}
	